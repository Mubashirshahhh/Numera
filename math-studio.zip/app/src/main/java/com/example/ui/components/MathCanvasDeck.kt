package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MathJobEntity
import com.example.domain.MathEngine
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentYellow
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MathCanvasDeck(
    job: MathJobEntity?,
    activeStage: String,
    animX: Float,
    isPlaying: Boolean,
    showTangent: Boolean,
    showIntegral: Boolean,
    zoom: Float,
    onTogglePlay: () -> Unit,
    onToggleTangent: () -> Unit,
    onToggleIntegral: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(340.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(DeepObsidian)
            .border(1.5.dp, SlateBorder, RoundedCornerShape(16.dp))
    ) {
        if (job == null) {
            EmptyStudioPlaceholder()
        } else if (job.status != "completed") {
            ActiveRenderOverlay(job = job, activeStage = activeStage)
        } else {
            // Active Manim Animation Deck
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val centerX = w / 2f
                val centerY = h / 2f
                val scale = (w / 12f) * zoom

                // 1. Draw Grid Lines
                val stepPx = scale
                var xTick = centerX % stepPx
                while (xTick < w) {
                    drawLine(Color(0xFF1E293B), Offset(xTick, 0f), Offset(xTick, h), strokeWidth = 1f)
                    xTick += stepPx
                }
                var yTick = centerY % stepPx
                while (yTick < h) {
                    drawLine(Color(0xFF1E293B), Offset(0f, yTick), Offset(w, yTick), strokeWidth = 1f)
                    yTick += stepPx
                }

                // 2. Draw Main Coordinate Axes
                drawLine(ElectricBlue, Offset(0f, centerY), Offset(w, centerY), strokeWidth = 2.5f)
                drawLine(ElectricBlue, Offset(centerX, 0f), Offset(centerX, h), strokeWidth = 2.5f)

                // 3. Integral Shaded Area (from -4 to animX)
                if (showIntegral) {
                    val integralPath = Path()
                    val startX = -4f
                    val endX = animX
                    val steps = 80
                    val dx = (endX - startX) / steps
                    
                    integralPath.moveTo(centerX + startX * scale, centerY)
                    for (i in 0..steps) {
                        val currX = startX + i * dx
                        val currY = MathEngine.evalCurve(job.graphType, job.cleanExpression, currX)
                        val px = centerX + currX * scale
                        val py = centerY - currY * scale
                        integralPath.lineTo(px, py)
                    }
                    integralPath.lineTo(centerX + endX * scale, centerY)
                    integralPath.close()

                    drawPath(integralPath, color = ElectricBlue.copy(alpha = 0.35f))
                    drawPath(integralPath, color = NeonCyan.copy(alpha = 0.5f), style = Stroke(width = 1.5f))
                }

                // 4. Draw Smooth Mathematical Curve f(x)
                val curvePath = Path()
                val numPoints = 200
                val minX = -5.5f / zoom
                val maxX = 5.5f / zoom
                val dx = (maxX - minX) / numPoints

                var isFirst = true
                for (i in 0..numPoints) {
                    val cx = minX + i * dx
                    val cy = MathEngine.evalCurve(job.graphType, job.cleanExpression, cx)
                    val px = centerX + cx * scale
                    val py = centerY - cy * scale

                    if (isFirst) {
                        curvePath.moveTo(px, py)
                        isFirst = false
                    } else {
                        curvePath.lineTo(px, py)
                    }
                }
                drawPath(curvePath, color = NeonCyan, style = Stroke(width = 3.5f, cap = StrokeCap.Round))

                // 5. Tangent Line (Derivative Slope) & Sliding Value Dot
                val curY = MathEngine.evalCurve(job.graphType, job.cleanExpression, animX)
                val dotPx = centerX + animX * scale
                val dotPy = centerY - curY * scale

                if (showTangent) {
                    val slope = MathEngine.evalDerivative(job.graphType, job.cleanExpression, animX)
                    val tanSpan = 1.8f
                    val tX1 = animX - tanSpan
                    val tY1 = curY - slope * tanSpan
                    val tX2 = animX + tanSpan
                    val tY2 = curY + slope * tanSpan

                    val px1 = centerX + tX1 * scale
                    val py1 = centerY - tY1 * scale
                    val px2 = centerX + tX2 * scale
                    val py2 = centerY - tY2 * scale

                    drawLine(AccentPink, Offset(px1, py1), Offset(px2, py2), strokeWidth = 3f, cap = StrokeCap.Round)
                }

                // Dot Glow & Center
                drawCircle(AccentYellow.copy(alpha = 0.35f), radius = 14f, center = Offset(dotPx, dotPy))
                drawCircle(AccentYellow, radius = 7f, center = Offset(dotPx, dotPy))
                drawCircle(Color.White, radius = 3f, center = Offset(dotPx, dotPy))
            }

            // HUD Telemetry Overlay (Top Left)
            val currYVal = MathEngine.evalCurve(job.graphType, job.cleanExpression, animX)
            val currSlopeVal = MathEngine.evalDerivative(job.graphType, job.cleanExpression, animX)
            
            Column(
                modifier = Modifier
                    .padding(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                    .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "TELEMETRY HUD • ${job.jobId}",
                    color = ElectricBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = String.format(Locale.US, "x: %+.2f | f(x): %+.2f", animX, currYVal),
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
                if (showTangent) {
                    Text(
                        text = String.format(Locale.US, "d/dx [slope]: %+.2f", currSlopeVal),
                        color = AccentPink,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Bottom Toolbar Controls
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A).copy(alpha = 0.9f))
                    .border(1.dp, SlateBorder, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("play_pause_button"),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = ElectricBlue, contentColor = Color.White)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause animation" else "Play animation",
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    FilterChip(
                        selected = showTangent,
                        onClick = onToggleTangent,
                        modifier = Modifier.testTag("tangent_toggle"),
                        label = { Text("Tangent d/dx", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.ShowChart, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentPink.copy(alpha = 0.25f),
                            selectedLabelColor = AccentPink,
                            selectedLeadingIconColor = AccentPink
                        )
                    )

                    FilterChip(
                        selected = showIntegral,
                        onClick = onToggleIntegral,
                        modifier = Modifier.testTag("integral_toggle"),
                        label = { Text("Area ∫dx", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan.copy(alpha = 0.25f),
                            selectedLabelColor = NeonCyan,
                            selectedLeadingIconColor = NeonCyan
                        )
                    )
                }

                // Zoom Deck
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onZoomOut, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Remove, contentDescription = "Zoom out", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "${(zoom * 100).toInt()}%",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onZoomIn, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Add, contentDescription = "Zoom in", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveRenderOverlay(job: MathJobEntity, activeStage: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(800, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepObsidian)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = NeonCyan, strokeWidth = 4.dp, modifier = Modifier.size(56.dp))
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "SYNTHESIZING MANIM SCENE",
            color = NeonCyan.copy(alpha = alpha),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = activeStage,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Job ID: ${job.jobId} • Status: ${job.status.uppercase()}",
            color = TextSecondary,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun EmptyStudioPlaceholder() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Functions,
            contentDescription = null,
            tint = ElectricBlue.copy(alpha = 0.6f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "MATH STUDIO CANVAS IDLE",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Enter an equation or select a sample below to synthesize",
            color = TextSecondary,
            fontSize = 13.sp
        )
    }
}
