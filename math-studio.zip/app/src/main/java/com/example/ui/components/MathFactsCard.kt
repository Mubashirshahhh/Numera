package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MathJobEntity
import com.example.domain.MathFacts
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentPink
import com.example.ui.theme.DeepObsidian
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File

@Composable
fun MathFactsCard(
    job: MathJobEntity,
    modifier: Modifier = Modifier
) {
    val mathFacts = remember(job) { MathFacts.fromJob(job) }
    var showLatex by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SlateCard)
            .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Calculate,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = "DETERMINISTIC MATH FACTS & LATEX",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(14.dp))
                Text("SymPy Verified", color = AccentGreen, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = SlateBorder)
        Spacer(modifier = Modifier.height(12.dp))

        // Equation Breakdown Table
        MathPropertyRow(label = "Primary Expression f(x)", value = job.cleanExpression, color = NeonCyan)
        Spacer(modifier = Modifier.height(8.dp))
        MathPropertyRow(label = "Exact Derivative d/dx", value = job.derivative, color = AccentPink)
        Spacer(modifier = Modifier.height(8.dp))
        MathPropertyRow(label = "Indefinite Integral ∫dx", value = job.integral, color = ElectricBlue)

        if (job.visualReport.isNotEmpty()) {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "SYNTHESIS REPORT:",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = job.visualReport,
                color = TextPrimary.copy(alpha = 0.9f),
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = SlateBorder)
        Spacer(modifier = Modifier.height(12.dp))

        // LaTeX Export & Download Deck
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    val latexContent = mathFacts.exportLatexString()
                    val fileName = "solution_${job.jobId}.tex"
                    try {
                        val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        val file = File(downloadsDir ?: context.cacheDir, fileName)
                        file.writeText(latexContent)

                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TITLE, fileName)
                            putExtra(Intent.EXTRA_SUBJECT, "LaTeX Math Solution (${job.jobId})")
                            putExtra(Intent.EXTRA_TEXT, latexContent)
                            type = "text/plain"
                        }
                        val chooser = Intent.createChooser(sendIntent, "Download/Export $fileName")
                        context.startActivity(chooser)
                        Toast.makeText(context, "Exported LaTeX solution ($fileName)!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("LaTeX Solution", latexContent))
                        Toast.makeText(context, "LaTeX copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .testTag("download_latex_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Download LaTeX (.tex)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("LaTeX Solution", mathFacts.exportLatexString()))
                    Toast.makeText(context, "LaTeX document copied!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = SlateBorder, contentColor = TextPrimary),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("copy_latex_button")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Copy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            IconButton(
                onClick = { showLatex = !showLatex },
                modifier = Modifier
                    .size(36.dp)
                    .background(DeepObsidian, RoundedCornerShape(8.dp))
                    .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = if (showLatex) Icons.Default.ExpandLess else Icons.Default.Code,
                    contentDescription = "Toggle LaTeX Preview",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        AnimatedVisibility(visible = showLatex) {
            Column(
                modifier = Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DeepObsidian)
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = latexSyntaxHighlight(mathFacts.exportLatexString()),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun MathPropertyRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column {
        Text(text = label, color = TextSecondary, fontSize = 11.sp)
        Text(
            text = value,
            color = color,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun latexSyntaxHighlight(code: String) = buildAnnotatedString {
    val lines = code.split("\n")
    for (line in lines) {
        when {
            line.trim().startsWith("""\""") && (line.contains("documentclass") || line.contains("usepackage") || line.contains("begin") || line.contains("end")) -> {
                withStyle(SpanStyle(color = AccentPink, fontWeight = FontWeight.Bold)) { append(line + "\n") }
            }
            line.trim().startsWith("""\""") -> {
                withStyle(SpanStyle(color = NeonCyan)) { append(line + "\n") }
            }
            line.contains("""\[""") || line.contains("""\]""") || line.contains("""\frac""") -> {
                withStyle(SpanStyle(color = ElectricBlue)) { append(line + "\n") }
            }
            else -> {
                withStyle(SpanStyle(color = TextPrimary)) { append(line + "\n") }
            }
        }
    }
}
