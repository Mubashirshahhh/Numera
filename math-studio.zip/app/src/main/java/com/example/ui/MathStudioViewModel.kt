package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.MathJobEntity
import com.example.domain.MathEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

// HashRouter view state management
object HashRouter {
    const val HOME = "#home"
    const val PROJECTS = "#projects"
    const val SETTINGS = "#settings"
}

class MathStudioViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).mathJobDao()

    val allJobs: StateFlow<List<MathJobEntity>> = dao.getAllJobsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedJob = MutableStateFlow<MathJobEntity?>(null)
    val selectedJob: StateFlow<MathJobEntity?> = _selectedJob.asStateFlow()

    private val _inputText = MutableStateFlow("Evaluate derivative of x^2 + 3*x - 5")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing.asStateFlow()

    private val _activeStage = MutableStateFlow("Idle")
    val activeStage: StateFlow<String> = _activeStage.asStateFlow()

    // Animation Canvas Controls (ValueTracker simulation)
    private val _animationX = MutableStateFlow(-4f)
    val animationX: StateFlow<Float> = _animationX.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _showTangent = MutableStateFlow(true)
    val showTangent: StateFlow<Boolean> = _showTangent.asStateFlow()

    private val _showIntegral = MutableStateFlow(false)
    val showIntegral: StateFlow<Boolean> = _showIntegral.asStateFlow()

    private val _zoom = MutableStateFlow(1f)
    val zoom: StateFlow<Float> = _zoom.asStateFlow()

    private val _currentTab = MutableStateFlow("home") // "home", "projects", "settings"
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    private val _currentRoute = MutableStateFlow(HashRouter.HOME)
    val currentRoute: StateFlow<String> = _currentRoute.asStateFlow()

    private var animJob: Job? = null

    init {
        // Seed initial jobs from Python script example if empty
        viewModelScope.launch {
            delay(300)
            if (dao.getJobById("job_001") == null) {
                val res1 = MathEngine.synthesize("Evaluate derivative of x^2 + 3*x - 5")
                val seed1 = MathJobEntity(
                    jobId = "job_001",
                    status = "completed",
                    rawRequest = "Evaluate derivative of x^2 + 3*x - 5",
                    cleanExpression = res1.cleanExpression,
                    variable = res1.variable,
                    derivative = res1.derivative,
                    integral = res1.integral,
                    manimCode = res1.manimCode,
                    visualReport = res1.visualReport,
                    graphType = res1.graphType
                )
                dao.insertOrUpdateJob(seed1)
                
                val res2 = MathEngine.synthesize("Plot sin(x)")
                val seed2 = MathJobEntity(
                    jobId = "job_002",
                    status = "completed",
                    rawRequest = "Plot sin(x)",
                    cleanExpression = res2.cleanExpression,
                    variable = res2.variable,
                    derivative = res2.derivative,
                    integral = res2.integral,
                    manimCode = res2.manimCode,
                    visualReport = res2.visualReport,
                    graphType = res2.graphType
                )
                dao.insertOrUpdateJob(seed2)
                _selectedJob.value = seed1
            }
        }
        startCanvasLoop()
    }

    private fun startCanvasLoop() {
        animJob?.cancel()
        animJob = viewModelScope.launch {
            var step = 0.08f
            while (true) {
                delay(32)
                if (_isPlaying.value && _selectedJob.value?.status == "completed") {
                    var cur = _animationX.value + step
                    if (cur > 4.5f) {
                        cur = -4.5f
                        delay(400) // Brief pause at loop end
                    }
                    _animationX.value = cur
                }
            }
        }
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun setTab(tab: String) {
        _currentTab.value = tab
        _currentRoute.value = when (tab) {
            "home" -> HashRouter.HOME
            "settings" -> HashRouter.SETTINGS
            else -> HashRouter.PROJECTS
        }
    }

    fun createNewProject(category: String) {
        val sampleEq = when (category) {
            "Linear Equations" -> "Linear equation 3*x - 12 = 0"
            "Quadratic Equations" -> "Evaluate derivative of x^2 - 5*x + 6"
            "Derivatives" -> "Evaluate derivative of x^3 - 4*x"
            "Integrals" -> "Indefinite integral of 3*x^2 + 4*x"
            else -> "Evaluate derivative of x^2 + 3*x - 5"
        }
        _inputText.value = sampleEq
        _currentTab.value = "projects"
        _currentRoute.value = HashRouter.PROJECTS
        submitCurrentRequest()
    }

    fun selectJob(job: MathJobEntity) {
        _selectedJob.value = job
        _animationX.value = -4f
        _currentTab.value = "projects"
        _currentRoute.value = HashRouter.PROJECTS
    }

    fun togglePlay() {
        _isPlaying.value = !_isPlaying.value
    }

    fun toggleTangent() {
        _showTangent.value = !_showTangent.value
    }

    fun toggleIntegral() {
        _showIntegral.value = !_showIntegral.value
    }

    fun setZoom(newZoom: Float) {
        _zoom.value = newZoom.coerceIn(0.5f, 3f)
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearAllJobs()
            _selectedJob.value = null
        }
    }

    fun submitCurrentRequest() {
        val req = _inputText.value.trim()
        if (req.isEmpty() || _isSynthesizing.value) return

        viewModelScope.launch {
            _isSynthesizing.value = true
            val newId = "job_" + UUID.randomUUID().toString().substring(0, 6)
            
            val pendingJob = MathJobEntity(
                jobId = newId,
                status = "analyzing",
                rawRequest = req,
                cleanExpression = "...",
                variable = "x",
                derivative = "...",
                integral = "...",
                manimCode = "# [Sandbox Engine] Initializing MathScene...",
                visualReport = "Observability engine analyzing equation...",
                graphType = "poly"
            )
            dao.insertOrUpdateJob(pendingJob)
            _selectedJob.value = pendingJob

            _activeStage.value = "[1/4] SymPy Mathematical Analysis..."
            delay(450)

            val synthesis = MathEngine.synthesize(req)
            
            _activeStage.value = "[2/4] Semantic Invariant Verification..."
            val codingJob = pendingJob.copy(
                status = "coding",
                cleanExpression = synthesis.cleanExpression,
                variable = synthesis.variable,
                derivative = synthesis.derivative,
                integral = synthesis.integral,
                visualReport = synthesis.visualReport
            )
            dao.insertOrUpdateJob(codingJob)
            _selectedJob.value = codingJob
            delay(450)

            _activeStage.value = "[3/4] Synthesizing Manim Python Template..."
            val renderingJob = codingJob.copy(
                status = "rendering",
                manimCode = synthesis.manimCode,
                graphType = synthesis.graphType
            )
            dao.insertOrUpdateJob(renderingJob)
            _selectedJob.value = renderingJob
            delay(500)

            _activeStage.value = "[4/4] Executing Docker Container Sandbox..."
            delay(600)

            val completedJob = renderingJob.copy(status = "completed")
            dao.insertOrUpdateJob(completedJob)
            _selectedJob.value = completedJob

            _isSynthesizing.value = false
            _activeStage.value = "Completed"
            _animationX.value = -4f
        }
    }
}
