package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF2979FF)
val DeepObsidian = Color(0xFF0A0E17)
val SlateCard = Color(0xFF161D2E)
val SlateBorder = Color(0xFF25314C)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val AccentPink = Color(0xFFFF2A6D)
val AccentGreen = Color(0xFF00E676)
val AccentYellow = Color(0xFFFFD600)
