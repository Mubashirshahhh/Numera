package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MathJobDao {
    @Query("SELECT * FROM jobs ORDER BY updatedAt DESC")
    fun getAllJobsFlow(): Flow<List<MathJobEntity>>

    @Query("SELECT * FROM jobs WHERE jobId = :id")
    suspend fun getJobById(id: String): MathJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateJob(job: MathJobEntity)

    @Query("DELETE FROM jobs")
    suspend fun clearAllJobs()
}
