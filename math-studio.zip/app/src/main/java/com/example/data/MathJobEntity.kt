package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jobs")
data class MathJobEntity(
    @PrimaryKey val jobId: String,
    val status: String,
    val rawRequest: String,
    val cleanExpression: String,
    val variable: String,
    val derivative: String,
    val integral: String,
    val manimCode: String,
    val visualReport: String,
    val graphType: String,
    val error: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
