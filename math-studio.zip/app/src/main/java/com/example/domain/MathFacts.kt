package com.example.domain

import com.example.data.MathJobEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MathFacts(
    val rawInput: String,
    val parsedClean: Boolean,
    val expression: String = "",
    val variable: String = "x",
    val derivative: String = "",
    val integral: String = "",
    val steps: List<String> = emptyList(),
    val jobId: String = ""
) {
    companion object {
        fun fromJob(job: MathJobEntity): MathFacts {
            val stepLines = job.visualReport
                .split("\n")
                .map { it.removePrefix("• ").removePrefix("- ").trim() }
                .filter { it.isNotEmpty() }
            return MathFacts(
                rawInput = job.rawRequest,
                parsedClean = job.status != "failed",
                expression = job.cleanExpression,
                variable = job.variable,
                derivative = job.derivative,
                integral = job.integral,
                steps = stepLines,
                jobId = job.jobId
            )
        }
    }

    /**
     * Converts raw SymPy string notation (e.g., x^2 + 3*x - 5 or 1/3*x^3) to clean LaTeX math notation.
     */
    fun toLatexMath(expr: String): String {
        var clean = expr.replace("*", " ")
        // Replace fractions like 1/3 -> \frac{1}{3}
        clean = clean.replace(Regex("""(\d+)/(\d+)"""), """\\frac{$1}{$2}""")
        // Replace exponents like x^2 -> x^{2} or (x+1)^3 -> (x+1)^{3}
        clean = clean.replace(Regex("""\^(\w+)"""), """^{$1}""")
        clean = clean.replace("sin", """\\sin""")
        clean = clean.replace("cos", """\\cos""")
        clean = clean.replace("exp", """\\exp""")
        clean = clean.replace("log", """\\log""")
        return clean
    }

    /**
     * Generates a complete LaTeX formatted solution document string.
     */
    fun exportLatexString(): String {
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val stepsLatex = if (steps.isNotEmpty()) {
            steps.joinToString("\n") { "  \\item $it" }
        } else {
            "  \\item Symbolic computation verified via SymPy invariant checking."
        }

        val exprLatex = toLatexMath(expression)
        val derivLatex = toLatexMath(derivative)
        val integLatex = toLatexMath(integral)

        return """
\documentclass{article}
\usepackage{amsmath}
\usepackage{amssymb}
\usepackage{geometry}
\geometry{a4paper, margin=1in}

\title{Mathematical Problem Solution \& Analysis}
\author{Math Studio AI Synthesizer}
\date{$dateStr}

\begin{document}
\maketitle

\section*{Problem Statement}
\textbf{Job ID:} \texttt{$jobId} \\
\textbf{Natural Language Query:} ``$rawInput''

\section*{Symbolic Calculus Solutions}

\subsection*{1. Primary Functional Expression}
\[ f($variable) = $exprLatex \]

\subsection*{2. First Derivative $\frac{d}{d$variable}$}
\[ \frac{d}{d$variable} \left[ f($variable) \right] = $derivLatex \]

\subsection*{3. Indefinite Integral $\int f($variable) \, d$variable$}
\[ \int f($variable) \, d$variable = $integLatex + C \]

\section*{Step-by-Step Mathematical Reasoning}
\begin{itemize}
$stepsLatex
\end{itemize}

\vfill
\noindent\rule{\textwidth}{0.4pt} \\
\footnotesize{\textit{Generated automatically alongside sandbox video animation by Math Studio.}}
\end{document}
        """.trimIndent()
    }
}
